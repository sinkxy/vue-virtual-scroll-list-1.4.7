import App from './App.vue'
import createApp from '../common/createApp'

createApp(App)
